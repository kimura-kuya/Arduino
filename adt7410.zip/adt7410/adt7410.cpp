#include "adt7410.h"
#include <Wire.h>


adt7410::adt7410(int adress){
  adt_ad = adress;
}

void adt7410::begin(){
  Wire.begin(adt_ad);
}

float adt7410::read(){
  uint16_t raw;
  float tp;
  Wire.requestFrom(adt_ad, 2);
  raw = (uint16_t)Wire.read() << 8;
  raw |= Wire.read();
  raw >>= 3;
  if (raw & 0x1000){
    tp = raw - 0x2000;
  }else{
    tp = raw;
  }
  return tp / 16.0;
}
