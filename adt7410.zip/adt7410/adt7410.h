#include "Arduino.h"
#ifndef _ADT7410_h
#define _ADT7410_h

class adt7410{
  public:
    adt7410(int adress);
  public:
    void begin();
    float read();
  private:
    int adt_ad;
};

void begin(int adress);

int read();

#endif
